# Capstone-Recommendation-Engine
To create a full-stack web application that recommends movies to users based on their preferences and past interactions. Finding relevant movies is difficult as user choices and preferences vary widely. Personalized recommendations simplify decision-making and improve user satisfaction.
